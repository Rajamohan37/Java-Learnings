package org.java.learning.abstraction;

public class SavingsAccount implements Account {

    double balance = 0;

    @Override
    public void open() {
        System.out.println("Opening Savings account ... ");
    }

    @Override
    public double deposit(double amount) {
        balance = balance + amount;
        return balance;
    }

    @Override
    public double getBalance() {
        return balance;
    }
}
