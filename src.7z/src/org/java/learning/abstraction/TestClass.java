package org.java.learning.abstraction;

public class TestClass {

    public static void main(String[] args) {
        System.out.println("============ Savings Account ========================");
        Account a2 = new SavingsAccount();
        a2.open();
        a2.deposit(500);
        System.out.println("Balance is " + a2.getBalance());
        a2.finish();
        System.out.println("============== Loan Account ======================");
        Account a3 = new LoanAccount();
        a3.open();
        a3.deposit(500);
        System.out.println("Balance is " + a3.getBalance());
        a3.finish();
    }
}
