package org.java.learning.abstraction;

public interface Account {

    void open();

    double deposit(double amount);

    double getBalance();

    default void finish() {
        System.out.println("Account opening is completed ... ");
    }

}