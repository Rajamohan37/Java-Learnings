package org.java.learning.abstraction;

public class LoanAccount implements Account {

    double leftover = 100000;

    @Override
    public void open() {
        System.out.println("Opening Loan Account .. ");
    }

    @Override
    public double deposit(double amount) {
        leftover = leftover - amount;
        return leftover;
    }

    @Override
    public double getBalance() {
        return leftover;
    }
}
