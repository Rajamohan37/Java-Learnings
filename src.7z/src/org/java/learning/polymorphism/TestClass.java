package org.java.learning.polymorphism;

public class TestClass {
    /*
        Poly:
            1. you have to have inheritance
            2. you have to override the methods
            3. you should do upcasting
     */
    public static void main(String[] args) {
        System.out.println("=========== Savings ===========================");
        Account a1 = new SavingsAccount();
        doOperations(a1);
        System.out.println("============= Loan =========================");
        Account a2 = new LoanAccount();
        doOperations(a2);
    }

    /**
     * Open an account
     * deposits money
     * gets the balance
     * Exit the bank
     *
     * @param account - type
     */
    public static void doOperations(Account account) {
        account.open();
        account.deposit(500);
        System.out.println("Balance is " + account.getBalance());
        account.finish();
    }
}
