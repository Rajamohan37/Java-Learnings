package org.java.learning.polymorphism;

public class SavingsAccount implements Account {

    double balance = 0;

    @Override
    public void open() {
        System.out.println("Opening Savings account ... ");
    }

    @Override
    public double deposit(double amount) {
        System.out.println("Adding " + amount + " to " + balance);
        balance = balance + amount;
        return balance;
    }

    @Override
    public double getBalance() {
        return balance;
    }
}
