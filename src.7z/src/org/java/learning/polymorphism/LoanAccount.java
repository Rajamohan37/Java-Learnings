package org.java.learning.polymorphism;

public class LoanAccount implements Account {

    double leftover = 100000;

    @Override
    public void open() {
        System.out.println("Opening Loan Account .. ");
    }

    @Override
    public double deposit(double amount) {
        System.out.println("Clearing " + amount + " from " + leftover);
        leftover = leftover - amount;
        return leftover;
    }

    @Override
    public double getBalance() {
        return leftover;
    }
}
