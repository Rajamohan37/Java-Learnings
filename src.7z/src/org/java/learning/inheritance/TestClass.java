package org.java.learning.inheritance;

public class TestClass {

    public static void main(String[] args) {
        // Start point
        Parent p1 = new Parent();
        p1.printX();

        Child c1 = new Child();
        c1.printName();


        Parent p2 = new Child();
        p2.printX();

        // End point

    }
}
