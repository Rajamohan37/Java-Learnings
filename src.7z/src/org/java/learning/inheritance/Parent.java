package org.java.learning.inheritance;

public class Parent {

    // 1. States / Variables
    private int x = 5;

    // 2. Behaviors / functions
        // 2.1 Normal functions
        // 2.2 Special functions

    public Parent() {
        super();
        System.out.println("Creating parent object");
    }

    public void printX() {
        System.out.println("X value from parent is " + x );
    }

}
