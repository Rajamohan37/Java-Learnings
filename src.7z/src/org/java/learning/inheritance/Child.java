package org.java.learning.inheritance;

public class Child extends Parent {

    private String name = "Rakesh";

    public Child() {
        super();
        System.out.println("Creating child object");
    }

    public void printName() {
        System.out.println("Name from child is " + name);
    }

}
