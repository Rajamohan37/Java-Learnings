package org.java.learning.encapsulation;

public class TestClass {

    public static void main(String[] args) {

        Customer c1 = new Customer(123, "Bryan");
        System.out.println(c1.getId() + "\t\t\t" + c1.getName());

        /*c1.setId(456);
        c1.setName("Ram");*/
        System.out.println(c1.getId() + "\t\t\t" + c1.getName());
    }
}
